package org.currencyservice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Hello world!
 *
 */
public class CurrencyConverterService 
{
    public Hashtable<String,Double> getConversion()
    {
    	String url="https://raw.githubusercontent.com/eswaribala/virtusa_aug2019/master/currency.txt";
    	Hashtable<String,Double> currencies=new Hashtable<String,Double>();
    	URL obj;
		try {
			obj = new URL(url);
			HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
			 con.setRequestMethod("GET");
			 int responseCode = con.getResponseCode();
			 BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			 String inputLine;
			 StringBuffer response = new StringBuffer();
				 
			 while ((inputLine = in.readLine()) != null) {
				        response.append(inputLine);
			 }
			 in.close();
				 
				        //print result
			System.out.println(response.toString());
			JSONParser parser = new JSONParser();
			JSONObject json=(JSONObject) parser.parse(response.toString());
			//System.out.print(json.get("rates"));
			Iterator<String> keyItr = json.keySet().iterator();
			String key=null;
			Object value=null;
			
			while(keyItr.hasNext())
			{
				key =keyItr.next();
				if(key.equalsIgnoreCase("rates"))
				{
					 value = json.get(key);
			           JSONObject innerjson = (JSONObject) parser.parse(value.toString()); 
			           Iterator<String> innerkeysItr = innerjson.keySet().iterator();
			           while(innerkeysItr.hasNext()) {
			        	   String innerKey = innerkeysItr.next();
			        	   Object innerValue = innerjson.get(innerKey);
			        	  // System.out.println(innerKey+","+innerValue);
			        	   currencies.put(innerKey, Double.parseDouble(innerValue.toString()));
			        	   System.out.println(innerKey+" "+Double.parseDouble(innerValue.toString()));
					  }
					 
				}
				
				
				
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return currencies;
    	
    }
}
