package com.virtusa.conversions.controller;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.currencyservice.CurrencyConverterService;

/**
 * Servlet implementation class CurrencyConversionServlet
 */
@WebServlet(name = "CurrencyConversionsServlet", urlPatterns = { "/CurrencyConversionsServlet" })
public class CurrencyConversionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CurrencyConversionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int amount=Integer.parseInt(request.getParameter("amount"));
		String currencyType=request.getParameter("toCurrencyName");
		System.out.println(amount+"   "+currencyType);
		//doGet(request, response);
		CurrencyConverterService currencyConverterService=new CurrencyConverterService();
		Hashtable<String,Double> currencies=currencyConverterService.getConversion();
		Iterator itr=currencies.keySet().iterator();
		String key=null;
		Double value=0.0;
		double conversionrate=0.0;
		String[] currency=currencyType.split("-");
		System.out.println(currency[1]);
		while(itr.hasNext())
		{
			
			key=(String)itr.next();
			System.out.println(key);
			if(key.equals(currency[1]))
			{
			System.out.println("ok");
			value=currencies.get(key);
			System.out.println(value);
			conversionrate=amount*value;
			//System.out.println(amount);
			//System.out.println(amount);
			break;
			}
		}
		System.out.println(conversionrate);
		request.setAttribute("rate",Math.round(conversionrate)+"");
		request.getRequestDispatcher("index.jsp").forward(request,response);
		
		
	}

}
