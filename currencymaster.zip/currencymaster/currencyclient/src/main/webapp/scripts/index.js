/**
 * 
 */
window.addEventListener('load',function()
{
	
	//alert("working");
	
	var ajaxObject=null;
	try
	{
		ajaxObject=new XMLHttpRequest();
	}
	catch(e)
	{
		try
		{
			ajaxObject=new ActivexmlObject("Msxml2.XMLHTTP3.0");
		}
		catch(e)
		{
			alert("Ajax object Support not available");
		}
	}
	
	
		var selectRef=document.querySelector("select")
		ajaxObject.open("get","https://restcountries.eu/rest/v2/all",true)
		
		//ajaxObject.setRequestHeader("Content-type","application/x-www-form-urlencoded;");
		ajaxObject.send(null)
		
		//use ready State Change event
		ajaxObject.onreadystatechange=function()
		{
			if((ajaxObject.readyState == 4)&&(ajaxObject.status==200))	
				{
				 data=JSON.parse(ajaxObject.responseText);
				 console.log(data)
			    /*for(var pos in data)
			    {
			    	for(var innerpos in data[pos])
			    		{
			    		 if(inner=="currencies")
			    			 {
			    			 for(var innermost in data[pos][innerpos])
			    				 {
			    				 console.log(data[pos][innerpos][innermost])
			    				 }
			    			 }
			    		}
			    }*/
				 for(var pos in data)
					 {
				   console.log(data[pos]['currencies'][0]['name']);
				   console.log(data[pos]['currencies'][0]['code']);
				   var currency=data[pos]['currencies'][0]['name']+"-"+data[pos]['currencies'][0]['code'];
				   option=document.createElement("option");
				   textNode=document.createTextNode(currency);
				   option.appendChild(textNode);
				   selectRef.appendChild(option);
					 }
				}
		}
		
		

	
});